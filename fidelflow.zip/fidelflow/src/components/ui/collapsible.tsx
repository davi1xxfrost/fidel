import * as CollapsiblePrimitive from "@radix-ui/react-collapsible"

const { Root: Collapsible } = CollapsiblePrimitive

const { CollapsibleTrigger } = CollapsiblePrimitive

const { CollapsibleContent } = CollapsiblePrimitive

export { Collapsible, CollapsibleTrigger, CollapsibleContent }
