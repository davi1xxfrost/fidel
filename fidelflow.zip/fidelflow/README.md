# 🎯 Fideliza - Sistema de Fidelidade para Barbearias

Um sistema moderno e elegante de fidelidade digital para barbearias, desenvolvido com React, TypeScript e Supabase.

## ✨ Características

- **🎨 Design Moderno**: Interface elegante e responsiva
- **📱 Mobile-First**: Otimizado para dispositivos móveis
- **🔐 Autenticação Segura**: Sistema de login robusto
- **📊 Dashboard Completo**: Gestão de clientes e pontos
- **🎁 Sistema de Recompensas**: Programa de fidelidade integrado
- **📱 QR Code**: Geração e leitura de códigos QR
- **⚡ Performance**: Otimizado para velocidade
- **🛡️ TypeScript**: Tipagem forte para maior segurança

## 🚀 Tecnologias

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS + Shadcn/ui
- **Backend**: Supabase (PostgreSQL + Auth)
- **Build Tool**: Vite
- **State Management**: React Context + TanStack Query
- **QR Code**: qrcode + qr-scanner
- **Icons**: Lucide React

## 📦 Instalação

```bash
# Clone o repositório
git clone https://github.com/seu-usuario/fideliza.git
cd fideliza

# Instale as dependências
npm install

# Configure as variáveis de ambiente
cp .env.example .env.local

# Inicie o servidor de desenvolvimento
npm run dev
```

## 🔧 Configuração

### Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
VITE_SUPABASE_URL=sua_url_do_supabase
VITE_SUPABASE_ANON_KEY=sua_chave_anonima_do_supabase
```

### Supabase Setup

1. Crie um projeto no [Supabase](https://supabase.com)
2. Execute as migrações do banco de dados
3. Configure as políticas RLS (Row Level Security)
4. Configure a autenticação

## 📁 Estrutura do Projeto

```
src/
├── components/          # Componentes reutilizáveis
│   ├── ui/            # Componentes base (shadcn/ui)
│   ├── ProtectedRoute.tsx
│   ├── QRCodeDisplay.tsx
│   └── QRCodeScanner.tsx
├── constants/          # Constantes e configurações
│   └── index.ts
├── context/           # Contextos React
│   ├── barbearia.ts
│   └── BarbeariaContext.tsx
├── hooks/             # Custom hooks
│   ├── use-barbearia.ts
│   ├── useQRCode.ts
│   └── useQRScanner.ts
├── integrations/      # Integrações externas
│   └── supabase/
├── lib/              # Utilitários
│   └── utils.ts
├── pages/            # Páginas da aplicação
│   ├── AdminDashboard.tsx
│   ├── BarbeariaDashboard.tsx
│   ├── BarbeariaPublica.tsx
│   └── ...
├── routes/           # Configuração de rotas
│   └── index.tsx
├── services/         # Serviços da API
│   └── api.ts
├── types/            # Definições de tipos
│   ├── index.ts
│   └── supabase-types.ts
├── App.tsx
└── main.tsx
```

## 🎯 Funcionalidades

### Para Barbearias
- **Dashboard Completo**: Visão geral de clientes e pontos
- **Gestão de Clientes**: Cadastro, edição e histórico
- **Sistema de Pontos**: Acumulação e resgate
- **Recompensas**: Configuração de benefícios
- **QR Code**: Geração de códigos para clientes
- **Relatórios**: Estatísticas e análises

### Para Clientes
- **Cartão Digital**: Visualização de pontos e nível
- **Histórico**: Transações e recompensas resgatadas
- **Feedback**: Avaliação de serviços
- **Recompensas**: Catálogo de benefícios disponíveis

### Para Administradores
- **Gestão de Barbearias**: Aprovação e configuração
- **Relatórios Globais**: Estatísticas do sistema
- **Configurações**: Parâmetros do sistema

## 🛠️ Scripts Disponíveis

```bash
# Desenvolvimento
npm run dev          # Inicia servidor de desenvolvimento
npm run build        # Build para produção
npm run preview      # Preview do build

# Qualidade de Código
npm run lint         # Executa ESLint
npm run lint:fix     # Corrige problemas do ESLint
npm run type-check   # Verifica tipos TypeScript

# Testes
npm run test         # Executa testes
npm run test:watch   # Testes em modo watch
```

## 🎨 Design System

O projeto utiliza um design system consistente baseado em:

- **Cores**: Paleta de cores slate/blue/purple
- **Tipografia**: Fonte Inter para melhor legibilidade
- **Componentes**: Shadcn/ui para consistência
- **Animações**: Transições suaves e micro-interações
- **Responsividade**: Mobile-first approach

## 🔒 Segurança

- **Autenticação**: Supabase Auth com JWT
- **Autorização**: Row Level Security (RLS)
- **Validação**: Validação de dados no frontend e backend
- **HTTPS**: Todas as comunicações criptografadas
- **Sanitização**: Prevenção contra XSS e injection

## 📱 Responsividade

O sistema é totalmente responsivo, otimizado para:

- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px
- **Desktop**: 1024px+

## 🚀 Deploy

### Vercel (Recomendado)

```bash
# Instale a CLI do Vercel
npm i -g vercel

# Deploy
vercel
```

### Netlify

```bash
# Build
npm run build

# Deploy manual ou via Git
```

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 📞 Suporte

- **Email**: suporte@fideliza.com
- **Documentação**: [docs.fideliza.com](https://docs.fideliza.com)
- **Issues**: [GitHub Issues](https://github.com/seu-usuario/fideliza/issues)

## 🙏 Agradecimentos

- [Supabase](https://supabase.com) pela infraestrutura
- [Shadcn/ui](https://ui.shadcn.com) pelos componentes
- [Tailwind CSS](https://tailwindcss.com) pelo styling
- [Vite](https://vitejs.dev) pela build tool

---

Desenvolvido com ❤️ pela equipe Fideliza 
#   f i d e l f l o w z  
 #   f i d e l  
 #   f i d e l  
 